class Student{
    constructor(id, nombre, apellido,
         cedula, materia, semestre, estatus){
             this.id= id;
             this.nombre= nombre;
             this.apellido= apellido;
             this.cedula= cedula;
             this.materia= materia;
             this.semestre= semestre;
             this.estatus= estatus

    }
}

module.exports = Student;